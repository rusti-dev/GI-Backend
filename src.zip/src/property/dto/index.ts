export * from './contract.dto';

export * from './create-image.dto';
export * from './update-image.dto';

export * from './create-property.dto';
export * from './update-property.dto';

export * from './create-property_owner.dto';
export * from './update-property_owner.dto';

export * from './create-ubicacion.dto';
export * from './update-ubicacion.dto';

export * from './upload-image.dto';
