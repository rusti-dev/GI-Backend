export interface IUserToken {
  role: string;
  sub: string;  
  isExpired: boolean;
}
