export interface IOwner {
  ci: string;
  name: string;
  email: string;
  phone: string;
  isActive: boolean;
}