export enum ROLE {
  ADMIN_SU = 'Administrador SU',
  ADMIN = 'Administrador TI',
}