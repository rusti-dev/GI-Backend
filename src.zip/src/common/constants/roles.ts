export enum ROLES {
  BASIC = 'basic',
  ADMIN = 'admin',
}
