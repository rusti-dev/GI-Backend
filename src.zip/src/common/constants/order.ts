export type ORDER = 'ASC' | 'DESC' | 'asc' | 'desc';
export enum ORDER_ENUM {
  ASC = 'ASC',
  DESC = 'DESC',
  asc = 'asc',
  desc = 'desc',
}