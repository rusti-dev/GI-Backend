export enum CURRENCY {
    BS = 'bs',
    USD = 'usd',
    USDT = 'usdt',
}