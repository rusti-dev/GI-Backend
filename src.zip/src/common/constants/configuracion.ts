export enum NOTIFICACTIONS {
    FAVORITOS = 'favoritos',
    OFERTAS = 'ofertas',
    SUSCRIPCIONES = 'suscripciones',
}

export enum GENDERS {
    MASCULINO = 'masculino',
    FEMENINO = 'femenino',
}

export const checkTokenGoogleUrl = `https://www.googleapis.com/oauth2/v3/userinfo?access_token=`;